#include "header.h"

int main(void)
{

	play();
	return 0;
}